# Ate-o-Fim Bot 2.0
Bot fofo e interativo para casais, pronto para GitHub + Railway.